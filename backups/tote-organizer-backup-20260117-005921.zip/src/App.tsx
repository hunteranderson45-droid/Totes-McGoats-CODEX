import ToteOrganizer from './components/ToteOrganizer'

function App() {
  return <ToteOrganizer />
}

export default App
